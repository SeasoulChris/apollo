from planning_analytics.apl_proto.modules.map.proto import map_pb2
from planning_analytics.common import proto_utils


class MapReader:
    def __init__(self, map_fn):
        self.map_fn = map_fn
        self.laneid_to_coord = {}

    def load_lane_id_to_coord(self, ):
        map_pb = map_pb2.Map()
        proto_utils.get_pb_from_file(self.map_fn, map_pb)
        for lane in map_pb.lane:
            print("laneid = " + lane.id.id)

            lane_coords = []
            for curve in lane.central_curve.segment:
                if curve.HasField('line_segment'):
                    for p in curve.line_segment.point:
                        x = p.x
                        y = p.y
                        lane_coords.append((x, y))

            self.laneid_to_coord[lane.id.id] = lane_coords

    def get_laneid_coord(self, lane_id):
        if lane_id in self.laneid_to_coord:
            return self.laneid_to_coord[lane_id]
        else:
            return None
