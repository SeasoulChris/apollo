from planning_analytics.record_viewer.agent_viewer import mkz_plotter


class AgentViewer:
    def __init__(self):
        pass

    def plot_agent(self, localization_pb, ax, c, ref_path=None):
        heading = localization_pb.pose.heading
        position = []
        position.append(localization_pb.pose.position.x)
        position.append(localization_pb.pose.position.y)
        position.append(localization_pb.pose.position.z)
        mkz_plotter.plot(position, heading, ax, c, ref_path)

