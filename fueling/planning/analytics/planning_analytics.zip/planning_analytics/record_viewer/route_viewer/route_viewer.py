#!/usr/bin/env python3
from shapely.geometry import LineString
from shapely.geometry import Point

from planning_analytics.map_reader.map_reader import MapReader


class RouteViewer:
    def __init__(self, map_fn):
        self.map_reader = MapReader(map_fn)
        self.map_reader.load_lane_info()
        self.map_reader.load_lane_id_to_coord()
        self.map_reader.load_xy_to_lane_id()

    def plot(self, routing_response, ax):
        # colors = ["b", "r", "g", "k"]
        colors = ["k"]
        cnt = 1
        for road in routing_response.road:
            ind = cnt % len(colors)
            cnt += 1
            c = colors[ind]
            passage_cnt = 1
            for passage in road.passage:
                passage_cnt += 1
                for segment in passage.segment:
                    # print(segment.id)
                    coords = self.map_reader.get_laneid_coord(segment.id)
                    if coords is None:
                        print("didn't found lane id: " + segment.id)
                    else:
                        x = []
                        y = []
                        for coord in coords:
                            x.append(coord[0])
                            y.append(coord[1])
                        # ax.plot(x, y, lw=0.5, c=c, marker=pt)
                        ax.plot(x, y, lw=8, c=c, alpha=0.1)

    def plot_with_location(self, routing_response, ax, fist_loc, last_loc):
        started = False
        ended = False

        x = fist_loc.pose.position.x
        y = fist_loc.pose.position.y
        p_start = Point(x, y)
        ax.plot([x], [y], 'bo')

        x = last_loc.pose.position.x
        y = last_loc.pose.position.y
        p_end = Point(x, y)
        ax.plot([x], [y], 'bo')

        # colors = ["b", "r", "g", "k"]
        colors = ["k"]
        cnt = 1
        for road in routing_response.road:
            ind = cnt % len(colors)
            cnt += 1
            c = colors[ind]
            passage_cnt = 1
            passage_pt = [".", "o", "v"]
            for passage in road.passage:
                pind = passage_cnt % len(passage_pt)
                pt = passage_pt[pind]
                passage_cnt += 1
                passage_string = []
                for segment in passage.segment:
                    # logging.info(segment.id)
                    coords = self.map_reader.get_laneid_coord(segment.id)
                    if coords is None:
                        print("didn't found lane id: " + segment.id)
                    else:
                        for coord in coords:
                            passage_string.append((coord[0], coord[1]))

                string = LineString(passage_string)
                if not started:
                    if p_start.distance(string) < 25:
                        self.plot_passage(ax, passage_string)
                        started = True

                if started and not ended:
                    if p_end.distance(string) < 10:
                        ended = True
                    self.plot_passage(ax, passage_string)

                if started and ended:
                    break

    def plot_passage(self, ax, passage):
        x = []
        y = []
        for p in passage:
            x.append(p[0])
            y.append(p[1])
        ax.plot(x, y, lw=8, c="k", alpha=0.1)