import copy
import numpy as np
import matplotlib.pyplot as plt

from planning_analytics.apl_proto.modules.localization.proto import localization_pb2
from planning_analytics.apl_proto.modules.perception.proto.perception_obstacle_pb2 import PerceptionObstacles
from planning_analytics.apl_proto.modules.routing.proto.routing_pb2 import RoutingResponse
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.record_viewer.agent_viewer.agent_viewer import AgentViewer
from planning_analytics.record_viewer.obstacle_viewer.obstacle_viewer import ObstacleViewer
from planning_analytics.record_viewer.route_viewer.route_viewer import RouteViewer


class RecordViewer:
    def __init__(self, show_agent, show_obstacles, show_routing):
        self.agent_viewer = AgentViewer()
        self.show_agent = show_agent
        self.show_obstacles = show_obstacles
        self.show_routing = show_routing

    def view(self, record_fn, map_fn, ax, ref_path=None):
        reader = AplRecordReader()
        ncolor = 0
        for msg in reader.read_messages(record_fn):
            if msg.topic == "/apollo/perception/obstacles":
                ncolor += 1

        print("frame num =" + str(ncolor))
        colorVals = plt.cm.jet(np.linspace(0, 1, ncolor))

        reader = AplRecordReader()

        localization_pb = localization_pb2.LocalizationEstimate()
        first_localization = None
        last_localization = None

        is_localization_updated = False
        cnt = 0
        routing_resp_hist = None

        for msg in reader.read_messages(record_fn):

            if msg.topic == "/apollo/localization/pose":

                localization_pb.ParseFromString(msg.message)
                if first_localization is None:
                    first_localization = copy.deepcopy(localization_pb)
                last_localization = localization_pb
                is_localization_updated = True

            if msg.topic == "/apollo/perception/obstacles":
                if not is_localization_updated:
                    print("localization is not updated")
                    continue

                idx = cnt % ncolor
                c = colorVals[idx]
                cnt += 1

                if self.show_agent:
                    if ref_path is not None:
                        self.agent_viewer.plot_agent(localization_pb, ax, c, ref_path)
                    else:
                        self.agent_viewer.plot_agent(localization_pb, ax, c)

                if self.show_obstacles:
                    perception_obstacle_pb = PerceptionObstacles()
                    perception_obstacle_pb.ParseFromString(msg.message)
                    for obstacle in perception_obstacle_pb.perception_obstacle:
                        if ref_path is not None:
                            ObstacleViewer().plot(obstacle, ax, c, ref_path)
                        else:
                            ObstacleViewer().plot(obstacle, ax, c)
            if msg.topic == "/apollo/routing_response":
                # print("get " + msg.topic)
                routing_response = RoutingResponse()
                routing_response.ParseFromString(msg.message)
                routing_resp_hist = routing_response

        if self.show_routing:
            RouteViewer(map_fn).plot_with_location(
                routing_resp_hist, ax, first_localization, last_localization)
            RouteViewer(map_fn).plot(routing_resp_hist, ax)
