from planning_analytics.common.frenet_coord_converter import convert


class ObstacleViewer:
    def __init__(self):
        pass

    def plot(self, perception_obstacle, ax, color, ref_path=None):
        x = []
        y = []
        for point in perception_obstacle.polygon_point:
            if ref_path is not None:
                point = convert(ref_path, [point.x, point.y])
            else:
                point = [point.x, point.y]
            x.append(point[0])
            y.append(point[1])

        point = perception_obstacle.polygon_point[0]
        if ref_path is not None:
            point = convert(ref_path, [point.x, point.y])
        else:
            point = [point.x, point.y]
        x.append(point[0])
        y.append(point[1])
        if len(x) > 0:
            ax.plot(x, y, color=color, ls="-", lw=0.5)
