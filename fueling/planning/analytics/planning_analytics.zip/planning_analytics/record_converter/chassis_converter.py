#!/usr/bin/env python
from modules.canbus.proto.chassis_pb2 import Chassis


class ChassisConverter:
    def __init__(self):
        pass

    def convert(self, l4_chassis_bin):
        ap_chassis = Chassis()
        ap_chassis.ParseFromString(l4_chassis_bin)

        return ap_chassis