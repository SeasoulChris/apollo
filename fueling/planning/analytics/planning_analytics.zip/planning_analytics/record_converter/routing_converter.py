from modules.routing.proto.routing_pb2 import RoutingRequest


class RoutingRequestConverter:
    def __init__(self):
        pass

    def convert(self, l4_routing_request_bin):
        request = RoutingRequest()
        request.ParseFromString(l4_routing_request_bin)
        return request
