# Bazel Federation

*NOTE: This documentation site is a work in progress. It is very much
incomplete.*

-   [About](about.md)
-   [How to integrate rules into the Federation](how_to_integrate.md)
-   [Code](https://github.com/bazelbuild/bazel-federation)
-   [How CI is used to gate releases](ci.md)
