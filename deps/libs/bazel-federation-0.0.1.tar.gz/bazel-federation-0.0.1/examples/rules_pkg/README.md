# Sample for using rules_pkg

```
bazel build :*
tar tvf bazel-bin/sample.tar
```
