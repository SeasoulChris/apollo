# Sample for using Stardoc

```
bazel build :*
more bazel-bin/my_rule_doc.md
```
