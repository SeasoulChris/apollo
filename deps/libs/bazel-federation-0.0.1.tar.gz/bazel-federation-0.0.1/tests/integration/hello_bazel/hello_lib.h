#include <string>

std::string hello_lib_value();
