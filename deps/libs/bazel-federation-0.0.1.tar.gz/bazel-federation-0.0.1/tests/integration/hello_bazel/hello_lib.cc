#include "hello_lib.h"

#include <string>

std::string hello_lib_value() {
  return "Bazel";
}
