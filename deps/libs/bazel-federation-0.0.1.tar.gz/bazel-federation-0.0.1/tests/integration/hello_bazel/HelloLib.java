package example;

public class HelloLib {

  public static String HelloLibValue = "Bazel";
}
