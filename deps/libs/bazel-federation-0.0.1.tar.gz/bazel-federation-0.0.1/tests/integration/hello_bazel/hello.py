"""hello bazel"""

from __future__ import print_function


def main():
  print('Hello bazel')


if __name__ == '__main__':
  main()
