# Integration tests for the Bazel Federation

There is a single, WORKSPACE file containing all the rules which are part of the
Federation.

# To use

```
bazel build ...
bazel test ...
```
