This directory contains BUILD file templates for some of the third party repositories.
Ideally we would use the original files from the protobuf repo, but that would force us to have the third party repositories depend on protobuf, thus potentially introducing a dependency cycle.
