class RouteLane:
    def __init__(self, lane_id, cnt):
        self.lane_id = lane_id
        self.cnt = cnt
        self.success_route_lane_ids = []
        self.next_route_lane_id = None


class RouteSearch:
    def __init__(self, dict_route_lane):
        self.dict_route_lane = dict_route_lane
        self.visited_lane_ids = []

    def search(self, route_lane_id):
        self.visited_lane_ids.append(route_lane_id)

        route_lane = self.dict_route_lane[route_lane_id]
        if len(route_lane.success_route_lane_ids) == 0:
            return route_lane_id, route_lane.cnt

        # print(route_lane.lane_id, len(route_lane.success_route_lane))
        max_cnt = -1
        best_route_lane_id = None
        for success_route_lane_id in route_lane.success_route_lane_ids:
            if success_route_lane_id in self.visited_lane_ids:
                continue
            ret_route_lane_id, r_cnt = self.search(success_route_lane_id)
            if r_cnt > max_cnt:
                max_cnt = r_cnt
                best_route_lane_id = ret_route_lane_id

        self.dict_route_lane[route_lane_id].next_route_lane_id = best_route_lane_id
        ret_cnt = route_lane.cnt + max_cnt

        return route_lane_id, ret_cnt


if __name__ == "__main__":

    rl1 = RouteLane("1", 1)
    rl2 = RouteLane("2", 2)
    rl3 = RouteLane("3", 3)
    rl4 = RouteLane("4", 4)
    rl1.success_route_lane_ids = ["2", "3"]
    rl2.success_route_lane_ids = ["4"]

    d = dict()
    d['1'] = rl1
    d['2'] = rl2
    d['3'] = rl3
    d['4'] = rl4

    head_lane_id, cnt1 = RouteSearch(d).search(rl1.lane_id)
    print(head_lane_id, cnt1)
    print(d[head_lane_id].next_route_lane_id)