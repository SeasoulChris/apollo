import math

from shapely.geometry import LineString
from shapely.geometry import Point

from planning_analytics.apl_proto.modules.localization.proto import localization_pb2

from planning_analytics.apl_proto.modules.routing.proto.routing_pb2 import RoutingResponse
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.common.msg_topics import apl_localization_topic
from planning_analytics.map_reader.map_reader import MapReader
from planning_analytics.route_generator.route_search import RouteLane, RouteSearch


class RouteGenerator:
    def __init__(self, map_fn):
        self.map_reader = MapReader(map_fn)
        self.map_reader.load_lane_info()
        self.map_reader.load_lane_id_to_coord()
        self.map_reader.load_xy_to_lane_id()

        self.candidates_cnt = dict()

    def distance(self, p1, p2):
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

    def generate(self, record_fn):
        candidates = []
        self.candidates_cnt = dict()
        candidates_ordered = []

        record_reader = AplRecordReader()
        cnt = 0

        for msg in record_reader.read_messages(record_fn):
            if msg.topic == apl_localization_topic:
                cnt += 1
                # if cnt > 100:
                #     break
                localization_estimate = localization_pb2.LocalizationEstimate()
                localization_estimate.ParseFromString(msg.message)
                x = localization_estimate.pose.position.x
                y = localization_estimate.pose.position.y
                heading = localization_estimate.pose.heading
                lane_ids = self.map_reader.get_lane_ids(x, y)
                best_lane_ids = self.select_best_lane(x, y, heading, lane_ids)

                # if best_lane_id == u'1575_1_-2':
                # print(x, y, best_lane_id)
                for best_lane_id in best_lane_ids:
                    # print(best_lane_id)
                    if best_lane_id not in candidates_ordered:
                        candidates_ordered.append(best_lane_id)
                        self.candidates_cnt[best_lane_id] = 1
                    else:
                        self.candidates_cnt[best_lane_id] += 1

        # print(candidates)
        dict_route_lane = dict()

        for lane_id in candidates_ordered:
            route_lane = None
            if lane_id not in dict_route_lane:
                route_lane = RouteLane(lane_id, self.candidates_cnt[lane_id])
                # ordered_route_lane.append(route_lane)
                dict_route_lane[lane_id] = route_lane

            successor_lane_ids = self.map_reader.get_lane_successors(lane_id)
            for s_lane_id in successor_lane_ids:
                if s_lane_id not in candidates_ordered:
                    continue
                if s_lane_id not in dict_route_lane:
                    s_route_lane = RouteLane(s_lane_id, self.candidates_cnt[s_lane_id])
                    # ordered_route_lane.append(s_route_lane)
                    dict_route_lane[s_lane_id] = s_route_lane
                route_lane = dict_route_lane[lane_id]
                route_lane.success_route_lane_ids.append(s_lane_id)
                dict_route_lane[lane_id] = route_lane

        print(candidates_ordered)

        passenges = []
        if len(candidates_ordered) > 0:
            start_lane_id = candidates_ordered[0]
            while start_lane_id is not None:
                head_lane_id, cnt = RouteSearch(dict_route_lane).search(start_lane_id)
                passenge = []
                #print("print start")

                while head_lane_id is not None:
                    passenge.append(head_lane_id)
                    # print(head_lane_id)
                    head_lane_id = dict_route_lane[head_lane_id].next_route_lane_id
                passenges.append(passenge)
                ind = candidates_ordered.index(passenge[-1])
                if len(candidates_ordered) > ind + 2:
                    start_lane_id = candidates_ordered[ind + 1]
                else:
                    start_lane_id = None

                    #print("print end")


        """
        candidates = []
        for candidate in candidates_ordered:
            candidates.append([candidate, self.candidates_cnt[candidate]])
        passenges = self.process_candidates(candidates)
        """
        # print(passenges)

        routing_resp = self.passenges_to_routing_response(passenges)
        # print(routing_resp)
        return routing_resp

    def passenges_to_routing_response(self, passenges):
        routing_response = RoutingResponse()
        for lane_ids in passenges:
            road = routing_response.road.add()
            passage = road.passage.add()
            for lane_id in lane_ids:
                segment = passage.segment.add()
                segment.id = lane_id
                segment.start_s = 0
                segment.end_s = self.map_reader.get_lane_length(lane_id)
        return routing_response

    def select_best_lane(self, x, y, heading, lane_ids):
        best_lane_ids = []
        p = Point(x, y)
        mini_dist = 2.0

        for lane_id in lane_ids:
            if self.map_reader.get_lane_type(lane_id) != 2:
                continue
            lane_coord = self.map_reader.get_laneid_coord(lane_id)
            line = LineString(lane_coord)
            dist = line.distance(p)
            if self._is_wrong_direction(heading, p, line):
                continue

            if dist < mini_dist:
                best_lane_ids.append(lane_id)

        return best_lane_ids

    def _is_wrong_direction(self, heading, p, line):
        dist = line.project(p)
        if dist < line.length - 0.2:
            p1 = line.interpolate(dist)
            p2 = line.interpolate(dist + 0.2)
        else:
            p1 = line.interpolate(dist - 0.2)
            p2 = line.interpolate(dist)

        delta_x = p2.x - p1.x
        delta_y = p2.y - p1.y
        theta_radians = math.atan2(delta_y, delta_x)
        if abs(theta_radians - heading) > math.pi / 2.0:
            return True

        # print(theta_radians, heading)
        return False

    def process_candidates(self, candidates):
        passenges = []

        lane_ids_candidates = []

        for i in range(len(candidates)):
            candidate = candidates[i]
            lane_id = candidate[0]
            lane_ids_candidates.append(lane_id)

        while len(lane_ids_candidates) > 0:
            lane_id = lane_ids_candidates.pop(0)
            passenge = self._find_passenge(lane_id, lane_ids_candidates)
            print(passenge)
            passenges.append(passenge)

        return passenges

    def _find_passenge(self, lane_id, lane_ids_candidates):
        passenge = [lane_id]
        lid = lane_id
        while True:
            lid = self._find_successor_lane_id(lid, lane_ids_candidates)
            if lid is None:
                return passenge
            else:
                passenge.append(lid)

    def _find_successor_lane_id(self, lane_id, lane_ids_candidates):
        successors = self.map_reader.get_lane_successors(lane_id)

        max_cnt = 0
        best_lane_id = None

        for successor_lane_id in successors:

            if successor_lane_id in lane_ids_candidates:
                cnt = self.candidates_cnt[successor_lane_id]
                if cnt > max_cnt:
                    max_cnt = cnt
                    best_lane_id = successor_lane_id

        if best_lane_id is not None:
            while True:
                lid = lane_ids_candidates.pop(0)
                if lid == best_lane_id:
                    return best_lane_id
        return None
