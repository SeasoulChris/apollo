import math

from shapely.geometry import LineString
from shapely.geometry import Point

from modules.localization.proto import localization_pb2

from modules.routing.proto.routing_pb2 import RoutingResponse
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.common.msg_topics import apl_localization_topic
from planning_analytics.map_reader.map_reader import MapReader


class RouteGenerator:
    def __init__(self, map_fn):
        self.map_reader = MapReader(map_fn)
        self.map_reader.load_lane_info()
        self.map_reader.load_lane_id_to_coord()
        self.map_reader.load_xy_to_lane_id()

    def distance(self, p1, p2):
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

    def generate(self, record_fn):
        candidates = []

        record_reader = AplRecordReader()
        cnt = 0
        last_xy = None
        for msg in record_reader.read_messages(record_fn):
            if msg.topic == apl_localization_topic:
                cnt += 1
                #if cnt > 100:
                #    break
                localization_estimate = localization_pb2.LocalizationEstimate()
                localization_estimate.ParseFromString(msg.message)
                x = localization_estimate.pose.position.x
                y = localization_estimate.pose.position.y
                heading = localization_estimate.pose.heading
                lane_ids = self.map_reader.get_lane_ids(x, y)
                best_lane_id = self.select_best_lane(x, y, heading, lane_ids)

                # if best_lane_id == u'1575_1_-2':
                # print(x, y, best_lane_id)
                if best_lane_id is not None:
                    if last_xy is not None:
                        dist = self.distance(last_xy, (x, y))
                    else:
                        dist = 0
                    if len(candidates) > 0 and best_lane_id == candidates[-1][0]:
                        candidates[-1][1] += dist
                    else:
                        candidates.append([best_lane_id, dist])
                last_xy = (x, y)

        # print(candidates)
        passenges = self.process_candidates(candidates)
        # print(passenges)
        routing_resp = self.passenges_to_routing_response(passenges)
        # print(routing_resp)
        return routing_resp

    def passenges_to_routing_response(self, passenges):
        routing_response = RoutingResponse()
        for lane_ids in passenges:
            road = routing_response.road.add()
            passage = road.passage.add()
            for lane_id in lane_ids:
                segment = passage.segment.add()
                segment.id = lane_id
                segment.start_s = 0
                segment.end_s = self.map_reader.get_lane_length(lane_id)
        return routing_response

    def select_best_lane(self, x, y, heading, lane_ids):
        p = Point(x, y)
        mini_dist = 999999
        best_lane_id = None
        for lane_id in lane_ids:
            if self.map_reader.get_lane_type(lane_id) != 2:
                continue
            lane_coord = self.map_reader.get_laneid_coord(lane_id)
            dist = LineString(lane_coord).distance(p)
            # print(dist, lane_id)
            if dist < mini_dist:
                mini_dist = dist
                best_lane_id = lane_id

        # print(mini_dist)
        return best_lane_id

    def process_candidates(self, candidates):
        passenges = []

        lane_ids_candidates = []

        for i in range(len(candidates)):
            candidate = candidates[i]
            lane_id = candidate[0]
            lane_ids_candidates.append(lane_id)

        while len(lane_ids_candidates) > 0:
            lane_id = lane_ids_candidates.pop(0)
            passenge = self._find_passenge(lane_id, lane_ids_candidates)
            passenges.append(passenge)
        return passenges

    def _find_passenge(self, lane_id, lane_ids_candidates):
        passenge = [lane_id]

        while True:
            lid = self._find_successor_lane_id(lane_id, lane_ids_candidates)
            if lid is None:
                return passenge
            else:
                passenge.append(lid)

    def _find_successor_lane_id(self, lane_id, lane_ids_candidates):
        successors = self.map_reader.get_lane_successors(lane_id)
        for successor_lane_id in successors:
            if successor_lane_id in lane_ids_candidates:
                while True:
                    lid = lane_ids_candidates.pop(0)
                    if lid == successor_lane_id:
                        return successor_lane_id
        return None
