#!/usr/bin/env python
import collections
import struct
import sys

from planning_analytics.tlz_record_reader.cybertron_record_pb2 import ChunkHeader
from planning_analytics.tlz_record_reader.cybertron_record_pb2 import ChunkSection
from planning_analytics.tlz_record_reader.cybertron_record_pb2 import HeaderSection
from planning_analytics.tlz_record_reader.cybertron_record_pb2 import ParamSection, IndexSection, ReserveSection

PyBagMessage = collections.namedtuple('PyBagMessage',
                                      'topic message data_type timestamp')


class TlzRecordReader:
    def __init__(self):
        pass

    def read_messages(self, file_name):
        with open(file_name, 'rb') as f:
            result = []
            cnt = 0
            while True:
                cnt += 1
                if cnt > 14:
                    pass

                section_len_bytes = f.read(8)
                if len(section_len_bytes) < 8:
                    print("EOF")
                    break

                section_len = struct.unpack('q', section_len_bytes)[0]
                #print("-------------------------------------------")
                #print("len=", section_len)

                section_type_bytes = f.read(4)
                section_type = struct.unpack('i', section_type_bytes)[0]
                #print("type=", section_type)

                f.read(4)

                if section_type == 7:
                    header = HeaderSection()
                    header.ParseFromString(f.read(2048000))
                    # print(header)
                    for channel in header.channels:
                        pass
                        # print("---")
                        # print(channel.name)
                        # print(channel.type)
                    # break
                elif section_type == 1:
                    header = HeaderSection()
                    header.ParseFromString(f.read(204800))

                elif section_type == 5:
                    param = ParamSection()
                    param.ParseFromString(f.read(section_len))

                elif section_type == 2:
                    header = ChunkHeader()
                    header.ParseFromString(f.read(section_len))
                    #print("header.rawsize = " + str(header.rawsize))

                elif section_type == 3:
                    section = ChunkSection()
                    section.ParseFromString(f.read(section_len))
                    #print("len(section.msgs) = " + str(len(section.msgs)))
                    for msg in section.msgs:
                        yield PyBagMessage(msg.channelname, msg.msg, "", msg.time)

                elif section_type == 4:
                    section = IndexSection()
                    section.ParseFromString(f.read(section_len))
                    # print("len(section.indexs) = " + str(len(section.indexs)))

                elif section_type == 6:
                    section = ReserveSection()
                    section.ParseFromString(f.read(section_len))

                else:
                    print("Error: unknown section type!")
                    break
