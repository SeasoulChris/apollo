from planning_analytics.analyzer.analyzer_chassis import ChassisAnalyzer
from planning_analytics.analyzer.analyzer_hmi import HmiAnalyzer
from planning_analytics.analyzer.analyzer_localization import LocalizationAnalyzer
from planning_analytics.analyzer.analyzer_perception import PerceptionAnalyzer
from planning_analytics.analyzer.analyzer_prediction import PredictionAnalyzer
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.route_analyzer.route_analyzer import RouteAnalyzer


class RecordCleaner:
    def __init__(self, map_file):
        self.msgs = list()
        self.msgs.append(list())

        self.topic_descs = dict()

        self.routing_analyzer = RouteAnalyzer(map_file)
        self.hmi_analyzer = HmiAnalyzer()

        self.localization_analyzer = LocalizationAnalyzer()
        self.chassis_analyzer = ChassisAnalyzer()

        self.perception_analyzer = PerceptionAnalyzer()
        self.prediction_analyzer = PredictionAnalyzer()

        self.topics = [
            '/apollo/canbus/chassis',
            '/apollo/localization/pose',
            '/apollo/hmi/status',
            '/apollo/perception/obstacles',
            '/apollo/perception/traffic_light',
            '/apollo/prediction',
            '/apollo/routing_request',
            '/apollo/routing_response',
            '/apollo/routing_response_history',
        ]

    def process_file(self, filename):
        # print_current_memory_usage("ProcessFile-before")

        reader = AplRecordReader()
        print("start reading messages...")

        for msg in reader.read_messages(filename):
            if msg.topic not in self.topics:
                continue

            if msg.topic == '/apollo/routing_response':
                self.routing_analyzer.set(msg)
                self.new_msg_list()

            if msg.topic == '/apollo/routing_response_history':
                if self.routing_analyzer.get_routing_response_msg() is None:
                    self.routing_analyzer.set(msg)

            if msg.topic == "/apollo/hmi/status":
                self.hmi_analyzer.update(msg)

            if msg.topic == '/apollo/perception/obstacles':

                perception_timestamp = PerceptionAnalyzer.get_msg_timstamp(msg)
                last_perception_timestamp = self.perception_analyzer.get_last_perception_timestamp()
                last_chassis_timestamp = self.chassis_analyzer.get_last_chassis_timestamp()
                last_localization_timestamp = \
                    self.localization_analyzer.get_last_localization_timestamp()
                last_prediction_timestamp = self.prediction_analyzer.get_last_prediction_timestamp()

                if abs(perception_timestamp - last_chassis_timestamp) > 0.05 \
                        or abs(perception_timestamp - last_localization_timestamp) > 0.05 \
                        or abs(perception_timestamp - last_prediction_timestamp) > 0.5 \
                        or abs(perception_timestamp - last_perception_timestamp) > 0.5:
                    print("Some msg is missing! ")
                    self.new_msg_list()

                self.perception_analyzer.update(msg)

            if msg.topic == '/apollo/prediction':
                self.prediction_analyzer.update(msg)

            if msg.topic == '/apollo/localization/pose':
                localization = self.localization_analyzer.get_localization_estimate(msg)
                if self.routing_analyzer.get_routing_response_msg() is not None and \
                        not self.routing_analyzer.is_adv_on_routing(localization):
                    print("ADV is not on routing! ")
                    self.new_msg_list()

                self.localization_analyzer.update(msg)

            if msg.topic == '/apollo/canbus/chassis':
                self.chassis_analyzer.update(msg)

            # add msg
            if self.routing_analyzer.get_routing_response_msg() is not None:
                self.msgs[-1].append(msg)

            if len(self.msgs) >= 200 * 60 * 5:
                self.new_msg_list()

        channels = reader.get_channels()
        for channel in channels:
            self.topic_descs[channel.name] = (channel.message_type, channel.proto_desc)

        #print_current_memory_usage("ProcessFile-after")
        #logging.info("")

    def new_msg_list(self):
        self.msgs.append(list())

        routing_msg = self.routing_analyzer.get_routing_response_msg()
        if routing_msg is not None:
            self.msgs[-1].append(routing_msg)
            if self.hmi_analyzer.get_hmi_status_msg() is not None:
                self.msgs[-1].append(self.hmi_analyzer.get_hmi_status_msg())

    def get_matured_msg_list(self):
        if len(self.msgs) > 1:
            return self.msgs[:-1]
        return []

    def clean_mature_msg_list(self):
        del self.msgs[:-1]
