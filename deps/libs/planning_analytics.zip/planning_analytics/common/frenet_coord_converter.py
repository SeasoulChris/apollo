import math

from shapely.geometry import LineString
from shapely.geometry import Point


def convert(reference_line_coords, point):
    point = Point(point[0], point[1])
    line = LineString(reference_line_coords)
    s = line.project(point)

    A = line.interpolate(s)
    B = line.interpolate(s + 0.1)
    x = point.x
    y = point.y
    l = line.distance(point)
    if ((B.x - A.x) * (y - A.y) - (B.y - A.y) * (x - A.x)) < 0:
        l = l * -1
    return s, l
