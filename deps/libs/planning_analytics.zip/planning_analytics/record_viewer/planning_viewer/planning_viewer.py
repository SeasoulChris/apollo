class PlanningViewer:
    def __init__(self):
        pass

    def plot_path(self, planning_pb, ax, color, marker):
        pathx = []
        pathy = []
        for trajectory_point in planning_pb.trajectory_point:
            x = trajectory_point.path_point.x
            y = trajectory_point.path_point.y
            pathx.append(x)
            pathy.append(y)

        # print(pathy)
        ax.plot(pathx, pathy, color=color, marker=marker, alpha=0.5)

