class PathViewer:
    def __init__(self):
        pass

    def plot_path(self, path_pb, ax, color, marker):
        pathx = []
        pathy = []
        for path_point in path_pb.path_point:
            x = path_point.x
            y = path_point.y
            pathx.append(x)
            pathy.append(y)

        # print(pathy)
        ax.plot(pathx, pathy, color=color, marker=marker, alpha=0.5)