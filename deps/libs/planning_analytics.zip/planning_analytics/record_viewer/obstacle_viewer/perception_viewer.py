from planning_analytics.record_viewer.obstacle_viewer.obstacle_viewer import ObstacleViewer


class PerceptionViewer:
    def __init__(self):
        pass

    def plot(self, percpetion_pb, ax, color):
        obs_viewer = ObstacleViewer()
        for obstacle in percpetion_pb.perception_obstacle:
                obs_viewer.plot(obstacle, ax, color)