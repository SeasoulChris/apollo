from planning_analytics.record_viewer.obstacle_viewer.obstacle_viewer import ObstacleViewer


class PerceptionViewer:
    def __init__(self):
        pass

    def plot(self, percpetion_pb, ax, color, obstacles=[]):
        obs_viewer = ObstacleViewer()
        for obstacle in percpetion_pb.perception_obstacle:
            if len(obstacles) > 0 and obstacle.id in obstacles:
                obs_viewer.plot(obstacle, ax, color)
