from planning_analytics.apl_proto.modules.localization.proto import localization_pb2
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.record_viewer.agent_viewer import mkz_plotter


class GpsViewer:
    def __init__(self):
        self.show_box = True
        self.show_point = True
        self.ref_path = None

    def set_show_box(self, show_box):
        self.show_box = show_box

    def set_show_point(self, show_point):
        self.show_point = show_point

    def set_ref_path(self, ref_path):
        self.ref_path = ref_path

    def plot_file(self, fn, ax, color):
        reader = AplRecordReader()
        cnt = 0
        for msg in reader.read_messages(fn):

            if msg.topic == "/apollo/localization/pose":
                cnt += 1
                localization_pb = localization_pb2.LocalizationEstimate()
                localization_pb.ParseFromString(msg.message)
                if cnt < 15:
                    pass
                    # print(localization_pb.header.timestamp_sec)
                    # print(msg.timestamp)
                self.plot_msg(localization_pb, ax, color)

    def plot_msg(self, gps_pb, ax, c, ref_path=None):
        position = []
        position.append(gps_pb.localization.position.x)
        position.append(gps_pb.localization.position.y)
        position.append(gps_pb.localization.position.z)
        heading = gps_pb.localization.heading

        if self.show_box:
            mkz_plotter.plot(position, heading, ax, c, ref_path)

        if self.show_point:
            ax.plot(position[0], position[1], color=c, marker='o', alpha=0.5)

    def get_agent_xy(self, localization_pb):
        heading = localization_pb.pose.heading
        position = []
        position.append(localization_pb.pose.position.x)
        position.append(localization_pb.pose.position.y)
        position.append(localization_pb.pose.position.z)
        polygon = mkz_plotter.get(position, heading)

        px = []
        py = []
        for point in polygon:
            px.append(point[0])
            py.append(point[1])
        point = polygon[0]
        px.append(point[0])
        py.append(point[1])

        return px, py
