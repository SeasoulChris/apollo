import math

from planning_analytics.apl_proto.modules.localization.proto import localization_pb2
from planning_analytics.apl_proto.modules.map.proto import map_pb2
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.common import frenet_coord_converter, proto_utils
from planning_analytics.map_reader.map_reader import MapReader


class MapPlotter:
    def __init__(self, map_fn):
        self.map_reader = MapReader(map_fn)
        self.map_reader.load_lane_id_to_coord()

    def plot_map(self, map_fn, ax, color="grey"):
        map_pb = map_pb2.Map()
        proto_utils.get_pb_from_file(map_fn, map_pb)

        for lane in map_pb.lane:
            self.plot_lane_id(ax, lane.id.id, color)

    def plot_lane_id(self, ax, lane_id, color="grey"):
        coords = self.map_reader.get_laneid_coord(lane_id)
        if coords is None:
            print("Lane Id not found: " + lane_id)
            return
        x = []
        y = []
        for coord in coords:
            x.append(coord[0])
            y.append(coord[1])

        ax.plot(x, y, color=color, alpha=0.5)

    def plot_lane_center_line(self, ax):
        pass

    def plot_lane_boundary(self, ax):
        pass

    def plot_frenet_lane_id(self, ax, lane_id, passage_coords):
        coords = self.map_reader.get_laneid_coord(lane_id)
        x = []
        y = []
        for coord in coords:
            s,l = frenet_coord_converter.convert(passage_coords, coord)
            x.append(s)
            y.append(l)

        ax.plot(x, y)

    def plot_record_map(self, ax, record_fn):
        self.map_reader.load_xy_to_lane_id()

        reader = AplRecordReader()
        last_x = 0
        last_y = 0
        lane_ids = []
        for msg in reader.read_messages(record_fn):
            if msg.topic == "/apollo/localization/pose":
                localization_pb = localization_pb2.LocalizationEstimate()
                localization_pb.ParseFromString(msg.message)
                x = localization_pb.pose.position.x
                y = localization_pb.pose.position.y
                dist = math.sqrt((x - last_x) * (x - last_x) + (y - last_y) * (y - last_y))
                # print dist
                if dist > 5.0:
                    lids = self.map_reader.get_lane_ids(x, y)

                    for lid in lids:
                        if lid not in lane_ids:
                            lane_ids.append(lid)
                    last_x = x
                    last_y = y

        for lane_id in lane_ids:
            # print(lane_id)
            self.plot_lane_id(ax, lane_id)