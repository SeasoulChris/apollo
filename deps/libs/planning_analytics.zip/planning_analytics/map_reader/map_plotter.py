from planning_analytics.common import frenet_coord_converter
from planning_analytics.map_reader.map_reader import MapReader


class MapPlotter:
    def __init__(self, map_fn):
        self.map_reader = MapReader(map_fn)
        self.map_reader.load_lane_id_to_coord()

    def plot_lane_id(self, ax, lane_id):
        coords = self.map_reader.get_laneid_coord(lane_id)
        x = []
        y = []
        for coord in coords:
            x.append(coord[0])
            y.append(coord[1])

        ax.plot(x, y)

    def plot_lane_center_line(self, ax):
        pass

    def plot_lane_boundary(self, ax):
        pass

    def plot_frenet_lane_id(self, ax, lane_id, passage_coords):
        coords = self.map_reader.get_laneid_coord(lane_id)
        x = []
        y = []
        for coord in coords:
            s,l = frenet_coord_converter.convert(passage_coords, coord)
            x.append(s)
            y.append(l)

        ax.plot(x, y)
