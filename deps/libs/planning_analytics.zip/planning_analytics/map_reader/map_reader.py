from shapely.geometry import LineString

from planning_analytics.apl_proto.modules.map.proto import map_pb2
from planning_analytics.common import proto_utils


class MapReader:
    def __init__(self, map_fn):
        self.map_fn = map_fn
        self.laneid_to_coord = dict()
        self.xy_to_laneid = dict()

        self.laneid_to_lane_type = dict()
        self.laneid_to_length = dict()
        self.laneid_to_successors = dict()

    def load_lane_id_to_coord(self, ):
        map_pb = map_pb2.Map()
        proto_utils.get_pb_from_file(self.map_fn, map_pb)
        for lane in map_pb.lane:
            # print("laneid = " + lane.id.id)

            lane_coords = []
            for curve in lane.central_curve.segment:
                if curve.HasField('line_segment'):
                    for p in curve.line_segment.point:
                        x = p.x
                        y = p.y
                        lane_coords.append((x, y))

            self.laneid_to_coord[lane.id.id] = lane_coords



    def load_lane_info(self, ):
        self.laneid_to_successors = dict()

        map_pb = map_pb2.Map()
        proto_utils.get_pb_from_file(self.map_fn, map_pb)
        for lane in map_pb.lane:
            # print("laneid = " + lane.id.id)

            successors = []
            for sid in lane.successor_id:
                successors.append(sid.id)

            self.laneid_to_successors[lane.id.id] = successors
            self.laneid_to_length[lane.id.id] = lane.length
            self.laneid_to_lane_type[lane.id.id] = lane.type

    def load_xy_to_lane_id(self):
        map_pb = map_pb2.Map()
        proto_utils.get_pb_from_file(self.map_fn, map_pb)
        for lane in map_pb.lane:

            lane_coords = []
            for curve in lane.central_curve.segment:
                if curve.HasField('line_segment'):
                    for p in curve.line_segment.point:
                        x = p.x
                        y = p.y
                        lane_coords.append((x, y))

            tile_idx = self.lane_coords_to_tile_index(lane_coords)
            for idx in tile_idx:
                if idx in self.xy_to_laneid:
                    self.xy_to_laneid[idx].append(lane.id.id)
                else:
                    self.xy_to_laneid[idx] = [lane.id.id]

    def lane_coords_to_tile_index(self, lane_coords):
        idx = []
        line = LineString(lane_coords)
        for i in range(int(line.length / 5) + 1):
            p = line.interpolate(i * 5)
            #for coord in lane_coords:
            x = round(p.x / 5.0) * 5
            y = round(p.y / 5.0) * 5
            xy = str(int(x)) + "," + str(int(y))
            # print(xy)
            if xy not in idx:
                idx.append(xy)
        return idx

    def get_lane_ids(self, x, y):
        lane_ids = []

        rx = round(x / 5.0) * 5
        ry = round(y / 5.0) * 5

        loop = [-5, 0, 5]

        for xaction in loop:
            x = rx + xaction
            for yaction in loop:
                y = ry + yaction
                xy = str(int(x)) + "," + str(int(y))
                if xy in self.xy_to_laneid:
                    for lid in self.xy_to_laneid[xy]:
                        if lid not in lane_ids:
                            lane_ids.append(lid)

        return lane_ids


    def get_laneid_coord(self, lane_id):
        if lane_id in self.laneid_to_coord:
            return self.laneid_to_coord[lane_id]
        else:
            return None

    def get_lane_successors(self, lane_id):
        if lane_id in self.laneid_to_successors:
            return self.laneid_to_successors[lane_id]
        else:
            return None

    def get_lane_type(self, lane_id):
        if lane_id in self.laneid_to_lane_type:
            return self.laneid_to_lane_type[lane_id]
        return None

    def get_lane_length(self, lane_id):
        if lane_id in self.laneid_to_length:
            return self.laneid_to_length[lane_id]
        return None