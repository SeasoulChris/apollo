import sys
from os import path
sys.path.append(path.dirname(path.abspath(__file__)) + "/apl_proto")
sys.path.append(path.dirname(path.abspath(__file__)) + "/tlz_proto")
