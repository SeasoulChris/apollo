#!/usr/bin/env python

import collections
import struct
import sys

from planning_analytics.apl_proto.cyber.proto.record_pb2 import Channel
from planning_analytics.apl_proto.cyber.proto.record_pb2 import ChunkBody
from planning_analytics.apl_proto.cyber.proto.record_pb2 import ChunkHeader
from planning_analytics.apl_proto.cyber.proto.record_pb2 import Index
from planning_analytics.apl_proto.cyber.proto.record_pb2 import Header

PyBagMessage = collections.namedtuple('PyBagMessage',
                                      'topic message data_type timestamp')


class AplRecordReader:
    def __init__(self):
        self.channels = []

    def get_channels(self):
        return self.channels

    def read_messages(self, file_name, topics=None):
        with open(file_name, 'rb') as f:
            while True:

                section_type_bytes = f.read(4)
                if len(section_type_bytes) < 4:
                    # print("EOF")
                    break
                f.read(4)

                section_type = struct.unpack('i', section_type_bytes)[0]

                section_len_bytes = f.read(4)
                section_len = struct.unpack('i', section_len_bytes)[0]
                f.read(4)
                # print(section_type)
                if section_type == 0:
                    try:
                        header = Header()
                        header.ParseFromString(f.read(2048))
                    except:
                        print("loading header is error!")
                        continue

                elif section_type == 4:
                    channel = Channel()
                    channel.ParseFromString(f.read(section_len))
                    self.channels.append(channel)

                elif section_type == 1:
                    chunk_header = ChunkHeader()
                    chunk_header.ParseFromString(f.read(section_len))

                elif section_type == 2:
                    chunk_body = ChunkBody()
                    try:
                        chunk_body.ParseFromString(f.read(section_len))
                    except:
                        print("loading chunk_body is error!")
                        continue

                    for message in chunk_body.messages:
                        if topics is None:
                            yield PyBagMessage(message.channel_name, message.content, "", message.time)
                        else:
                            if message.channel_name in topics:
                                yield PyBagMessage(message.channel_name, message.content, "", message.time)

                elif section_type == 3:
                    index = Index()
                    index.ParseFromString(f.read(section_len))
                    # print("index size = ", len(index.indexes))
                else:
                    print("section_type = " + str(section_type))
                    print("Error: unknown section type in Apollo Record!")
                    break


if __name__ == "__main__":
    fn = sys.argv[1]
    reader = AplRecordReader()
    for msg in reader.read_messages(fn):
        print(msg.topic)
        print(msg.timestamp)
