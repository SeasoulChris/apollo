import math

from planning_analytics.apl_proto.modules.canbus.proto.chassis_pb2 import Chassis
from planning_analytics.apl_proto.modules.localization.proto.localization_pb2 import LocalizationEstimate
from planning_analytics.apl_proto.modules.perception.proto.perception_obstacle_pb2 import PerceptionObstacles
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.route_analyzer.route_analyzer import RouteAnalyzer


class NudgeDetector:
    def __init__(self):
        self.is_nudge_cnt = 0
        self.not_nudge_cnt = 0
        self.last_localization = None
        self.last_chassis = None
        self.last_perception = None
        self.route_analyzer = None

    def set_route(self, route_resp_pb, map_fn):
        self.is_nudge_cnt = 0
        self.not_nudge_cnt = 0

        self.route_analyzer = RouteAnalyzer(map_fn)
        self.route_analyzer.set_route_response_pb(route_resp_pb)

    def update_frame(self, perception_pb, localization_pb, chassis_pb):
        self.last_perception = perception_pb
        self.last_localization = localization_pb
        self.last_chassis = chassis_pb
        is_frame_nudge = self._is_frame_nudge()
        if is_frame_nudge:
            self.is_nudge_cnt += 1
            if self.is_nudge_cnt > 20:
                self.not_nudge_cnt = 0
                self.is_nudge_cnt = 0
                return True
        else:
            self.not_nudge_cnt += 1
            if self.not_nudge_cnt > 20:
                self.is_nudge_cnt = 0
        return False

    def process_file(self, fn):  # TODO
        reader = AplRecordReader()
        for msg in reader.read_messages(fn):
            if msg.topic == "/apollo/perception/obstacles":
                perception_pb = PerceptionObstacles()
                perception_pb.ParseFromString(msg.message)
                self.last_perception = perception_pb

            if msg.topic == "/apollo/localization/pose":
                localization_pb = LocalizationEstimate()
                localization_pb.ParseFromString(msg.message)
                self.last_localization = localization_pb

            if msg.topic == '/apollo/canbus/chassis':
                chassis = Chassis()
                chassis.ParseFromString(msg.message)
                self.last_chassis = chassis

    def _is_frame_nudge(self):
        if self.last_localization is None:
            return False
        if self.last_chassis is None:
            return False
        if self.last_perception is None:
            return False
        if self.route_analyzer is None:
            return False
        adv_speed = self.last_chassis.speed_mps
        if adv_speed <= 7:
            return False

        x = self.last_localization.pose.position.x
        y = self.last_localization.pose.position.y
        route_line_idx = self.route_analyzer.get_route_line_idx(x, y)

        adv_s = self.route_analyzer.get_route_s(x, y, route_line_idx)
        adv_l = self.route_analyzer.get_route_l(x, y, route_line_idx)
        # print(adv_s, adv_l)

        for perception_obstacle in self.last_perception.perception_obstacle:
            speed_x = perception_obstacle.velocity.x
            speed_y = perception_obstacle.velocity.y
            speed = math.sqrt(speed_x * speed_x + speed_y * speed_y)
            if speed <= 7:
                continue
            if speed > adv_speed:
                continue

            x = perception_obstacle.position.x
            y = perception_obstacle.position.y
            obs_s = self.route_analyzer.get_route_s(x, y, route_line_idx)
            obs_l = self.route_analyzer.get_route_l(x, y, route_line_idx)

            if obs_l > 5:
                continue

            # print(obs_s, obs_l)
            if abs(adv_s - obs_s) > 20:
                continue
            if abs(adv_l - obs_l) > 2:
                continue

            if 2.0 < adv_l < 0.2:
                continue
            return True
        return False


