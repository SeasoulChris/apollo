from planning_analytics.apl_proto.modules.canbus.proto.chassis_pb2 import Chassis
from planning_analytics.apl_proto.modules.localization.proto.localization_pb2 import LocalizationEstimate
from planning_analytics.apl_proto.modules.perception.proto.perception_obstacle_pb2 import PerceptionObstacles
from planning_analytics.apl_proto.modules.routing.proto.routing_pb2 import RoutingResponse
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.nudge.nudge_detector import NudgeDetector


class RecordNudgeAnalzyer:
    def __init__(self):
        self.last_perception = None
        self.last_localization = None
        self.last_chassis = None
        self.detector = NudgeDetector()
        self.nudge_timestamps = []

    def process(self, record_fn, map_fn):
        self.nudge_timestamps = []

        reader = AplRecordReader()
        init_timestamp = None

        for msg in reader.read_messages(record_fn):
            if msg.topic == '/apollo/routing_response':
                routing_response = RoutingResponse()
                routing_response.ParseFromString(msg.message)
                self.detector.set_route(routing_response, map_fn)

            if msg.topic == "/apollo/perception/obstacles":
                perception_pb = PerceptionObstacles()
                perception_pb.ParseFromString(msg.message)
                if init_timestamp is None:
                    init_timestamp = perception_pb.header.timestamp_sec
                relative_time = perception_pb.header.timestamp_sec - init_timestamp
                self.last_perception = perception_pb
                is_nudge = self.detector.update_frame(self.last_perception, self.last_localization, self.last_chassis)
                if is_nudge:
                    self.nudge_timestamps.append(relative_time)

            if msg.topic == "/apollo/localization/pose":
                localization_pb = LocalizationEstimate()
                localization_pb.ParseFromString(msg.message)
                self.last_localization = localization_pb

            if msg.topic == '/apollo/canbus/chassis':
                chassis = Chassis()
                chassis.ParseFromString(msg.message)
                self.last_chassis = chassis

        return self.nudge_timestamps