import collections

from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.record_converter.chassis_converter import ChassisConverter
from planning_analytics.record_converter.localization_converter import LocalizationConverter
from planning_analytics.record_converter.perception_converter import PerceptionConverter
from planning_analytics.record_converter.prediction_converter import PredictionConverter
from planning_analytics.record_converter.routing_converter import RoutingRequestConverter
from planning_analytics.record_converter.traffic_light_converter import TrafficLightConverter
from planning_analytics.tlz_proto.global_adc_status_pb2 import Chassis
from planning_analytics.tlz_proto.localization_pose_pb2 import LocalizationEstimate
from planning_analytics.tlz_proto.perception_obstacle_pb2 import PerceptionObstacles
from planning_analytics.tlz_proto.prediction_obstacle_pb2 import PredictionObstacles

PyBagMessage = collections.namedtuple('PyBagMessage',
                                      'topic message data_type timestamp')


class RecordConverter:
    def __init__(self):
        # self.reader = TlzRecordReader()
        self.reader = AplRecordReader()

    def convert(self, fn):
        cnt = 0
        for msg in self.reader.read_messages(fn):
            # print(msg.topic)
            cnt += 1
            if msg.topic == '/localization/100hz/localization_pose':
                # print(msg.channelname)
                localization = LocalizationEstimate()
                localization.ParseFromString(msg.message)
                alocal = LocalizationConverter().convert(msg.message)

                apl_channel_name = '/apollo/localization/pose'
                yield PyBagMessage(apl_channel_name, alocal.SerializeToString(), "", msg.timestamp)

                # print(alocal.pose.position.x)
            if msg.topic == '/pnc/prediction':
                l4_prediction = PredictionObstacles()
                l4_prediction.ParseFromString(msg.message)
                apollo_prediction = PredictionConverter().convert(l4_prediction)

                apl_channel_name = '/apollo/prediction'
                yield PyBagMessage(apl_channel_name, apollo_prediction.SerializeToString(), "", msg.timestamp)

            if msg.topic == '/planning/proxy/DuDriveChassis':
                chassis = Chassis()
                chassis.ParseFromString(msg.message)

                ap_chassis = ChassisConverter().convert(chassis)

                apl_channel_name = '/apollo/canbus/chassis'
                yield PyBagMessage(apl_channel_name, ap_chassis.SerializeToString(), "", msg.timestamp)

            if msg.topic == '/perception/obstacles':
                l4_perception = PerceptionObstacles()
                l4_perception.ParseFromString(msg.message)

                apl_perception = PerceptionConverter().convert(l4_perception)
                apl_channel_name = '/apollo/perception/obstacles'
                yield PyBagMessage(apl_channel_name, apl_perception.SerializeToString(), "", msg.timestamp)

            if msg.topic == '/perception/traffic_light_trigger':
                pass
                # print(msg.topic)

            if msg.topic == '/perception/traffic_light_status':
                # print(msg.topic)
                ap_traffic_light = TrafficLightConverter().convert(msg.message)
                # print(ap_traffic_light)
                apl_channel_name = '/apollo/perception/traffic_light'
                yield PyBagMessage(apl_channel_name, ap_traffic_light.SerializeToString(), "", msg.timestamp)

            if msg.topic == '/router/routing_signal':
                apl_routing_request = RoutingRequestConverter().convert(msg.message)
                apl_channel_name = '/apollo/routing_request'
                yield PyBagMessage(apl_channel_name, apl_routing_request.SerializeToString(), "", msg.timestamp)

                # print(msg.topic)
            """
            if msg.topic == '/pnc/decision':
                print(msg.topic)
                decision = DecisionResult()
                decision.ParseFromString(msg.message)

                print(decision.debug)

            if msg.topic == '/datavision/routing_path':
                pass
                #print(msg.topic)
            """
        # print cnt


if __name__ == "__main__":
    import sys

    fn = sys.argv[1]
    converter = RecordConverter()
    converter.convert(fn)
