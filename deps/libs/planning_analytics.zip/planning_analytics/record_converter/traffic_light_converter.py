#!/usr/bin/env python
from planning_analytics.apl_proto.modules.perception.proto.traffic_light_detection_pb2 import \
    TrafficLightDetection


class TrafficLightConverter:
    def __init__(self):
        pass

    def convert(self, l4_traffic_light_bin):
        detection = TrafficLightDetection()
        detection.ParseFromString(l4_traffic_light_bin)
        return detection
