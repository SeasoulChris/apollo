#!/usr/bin/env python
from modules.canbus.proto.chassis_pb2 import Chassis


class ChassisConverter:
    def __init__(self):
        pass

    def convert(self, l4_chassis_pb):
        ap_chassis = Chassis()
        ap_chassis.engine_started = l4_chassis_pb.engine_started
        ap_chassis.engine_rpm = l4_chassis_pb.engine_rpm
        ap_chassis.speed_mps = l4_chassis_pb.speed_mps
        ap_chassis.odometer_m = l4_chassis_pb.odometer_m

        ap_chassis.fuel_range_m = l4_chassis_pb.fuel_range_m
        ap_chassis.throttle_percentage = l4_chassis_pb.throttle_percentage
        ap_chassis.brake_percentage = l4_chassis_pb.brake_percentage
        ap_chassis.steering_percentage = l4_chassis_pb.steering_percentage
        ap_chassis.steering_torque_nm = l4_chassis_pb.steering_torque_nm
        ap_chassis.parking_brake = l4_chassis_pb.parking_brake

        ap_chassis.driving_mode = l4_chassis_pb.driving_mode
        ap_chassis.error_code = l4_chassis_pb.error_code
        ap_chassis.gear_location = l4_chassis_pb.gear_location
        ap_chassis.steering_timestamp = l4_chassis_pb.steering_timestamp
        ap_chassis.header.ParseFromString(l4_chassis_pb.header.SerializeToString())

        ap_chassis.chassis_error_mask = l4_chassis_pb.chassis_error_mask

        # ap_chassis.ParseFromString(l4_chassis_bin)

        return ap_chassis