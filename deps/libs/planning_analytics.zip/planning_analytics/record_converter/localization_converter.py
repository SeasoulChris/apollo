#!/usr/bin/env python
import math

import numpy as np

from planning_analytics.apl_proto.modules.localization.proto.localization_pb2 import LocalizationEstimate


def quaternion_to_euler(w, x, y, z):
    """Converts quaternions with components w, x, y, z into a tuple (roll, pitch, yaw)"""
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x ** 2 + y ** 2)
    roll = np.arctan2(sinr_cosp, cosr_cosp)

    sinp = 2 * (w * y - z * x)
    pitch = np.where(np.abs(sinp) >= 1,
                     np.sign(sinp) * np.pi / 2,
                     np.arcsin(sinp))

    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y ** 2 + z ** 2)
    yaw = np.arctan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw


class LocalizationConverter:
    def __init__(self):
        pass

    def convert(self, polit_localization_bin):
        localization_pb = LocalizationEstimate()
        localization_pb.ParseFromString(polit_localization_bin)

        w = localization_pb.pose.orientation.qw
        x = localization_pb.pose.orientation.qx
        y = localization_pb.pose.orientation.qy
        z = localization_pb.pose.orientation.qz
        roll, pitch, yaw = quaternion_to_euler(w, x, y, z)

        localization_pb.pose.heading = yaw + math.pi / 2.0
        return localization_pb
