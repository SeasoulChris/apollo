import math

from planning_analytics.apl_proto.modules.localization.proto import localization_pb2
from planning_analytics.apl_proto.modules.planning.proto import planning_pb2
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from shapely.geometry import LineString
from shapely.geometry import Point


class ImitationAnalyzer:
    def __init__(self):
        self.gt_timestamps = []
        self.gt_locations = []
        self.de = []
        self.planning_locations_set = []

        self.path_errors = []
        self.displacement_errors = []
        self.use_model_ouput = []

    def get_imitation_scores(self, record_fn):
        self.gt_timestamps = []
        self.gt_locations = []
        self.de = []
        self.planning_locations_set = []

        reader = AplRecordReader()
        for msg in reader.read_messages(record_fn):
            # print(msg.topic)
            if msg.topic == '/apollo/localization/pose':
                localization_pb = localization_pb2.LocalizationEstimate()
                localization_pb.ParseFromString(msg.message)
                x = localization_pb.pose.position.x
                y = localization_pb.pose.position.y
                t = localization_pb.header.timestamp_sec
                # print(t)
                self.gt_timestamps.append(t)
                self.gt_locations.append((x, y))

        cnt = 0
        for msg in reader.read_messages(record_fn):
            if msg.topic == '/apollo/planning':
                cnt += 1
                if cnt < 20:
                    continue
                planning_timestamps = []
                planning_locations = []
                planning_pb = planning_pb2.ADCTrajectory()
                planning_pb.ParseFromString(msg.message)

                if planning_pb.debug.planning_data.HasField("hybrid_model"):
                    if not planning_pb.debug.planning_data.hybrid_model.using_learning_model_output:
                        self.use_model_ouput.append(0)
                    else:
                        self.use_model_ouput.append(1)
                else:
                    self.use_model_ouput.append(0)

                planning_time = planning_pb.header.timestamp_sec
                for traj_point in planning_pb.trajectory_point:
                    x = traj_point.path_point.x
                    y = traj_point.path_point.y
                    if traj_point.relative_time > 2.0:
                        break
                    t = traj_point.relative_time + planning_time
                    planning_timestamps.append(t)
                    planning_locations.append((x, y))

                self.planning_locations_set.append(planning_locations)

                self.calculate_path_error(planning_locations)
                self.calculate_displacement_error(planning_timestamps, planning_locations)

        metrics = dict()
        if len(self.path_errors) == 0:
            metrics["avg_path_error"] = 0
        else:
            metrics["avg_path_error"] = sum(self.path_errors) / len(self.path_errors)

        if len(self.displacement_errors) == 0:
            metrics["avg_displacement_error"] = 0
        else:
            metrics["avg_displacement_error"] = sum(self.displacement_errors) / len(self.displacement_errors)

        if len(self.use_model_ouput) == 0:
            metrics["model_usage_rate"] = 0
        else:
            metrics["model_usage_rate"] = sum(self.use_model_ouput) / float(len(self.use_model_ouput))

        return metrics

    def calculate_path_error(self, planning_locations):
        path_errors = []
        line = LineString(self.gt_locations)
        for loc in planning_locations:
            p = Point(loc[0], loc[1])
            dist0 = Point(self.gt_locations[-1][0], self.gt_locations[-1][1]).distance(p)
            dist = line.distance(p)
            if abs(dist0 - dist) < 0.1:
                continue
            self.path_errors.append(dist)
        return path_errors

    def calculate_displacement_error(self, planning_timestamps, planning_locations):
        displacement_errors = []
        for i in range(len(planning_timestamps)):
            t = planning_timestamps[i]
            (x, y) = planning_locations[i]

            idx = self.find_nearest_index(t)
            gt_location = self.gt_locations[idx]
            x1 = gt_location[0]
            y1 = gt_location[1]

            if abs(t - self.gt_timestamps[idx]) <= 0.1:
                e = math.sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1))
                self.displacement_errors.append(e)
            else:
                pass
        return displacement_errors

    def find_nearest_index(self, given_value):
        absolute_difference_function = lambda list_value: abs(list_value - given_value)

        closest_value = min(self.gt_timestamps, key=absolute_difference_function)
        # print(given_value, closest_value)
        closest_index = self.gt_timestamps.index(closest_value)
        return closest_index
