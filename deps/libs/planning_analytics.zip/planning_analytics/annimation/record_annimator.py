from __future__ import print_function

import time

import matplotlib.animation as animation
import matplotlib.pyplot as plt

from planning_analytics.apl_proto.modules.localization.proto import localization_pb2
from planning_analytics.apl_proto.modules.perception.proto.perception_obstacle_pb2 import PerceptionObstacles
from planning_analytics.apl_proto.modules.routing.proto.routing_pb2 import RoutingResponse
from planning_analytics.apl_record_reader.apl_record_reader import AplRecordReader
from planning_analytics.map_reader.map_reader import MapReader
from planning_analytics.record_viewer.agent_viewer.agent_viewer import AgentViewer
from planning_analytics.record_viewer.obstacle_viewer.obstacle_viewer import ObstacleViewer
from planning_analytics.record_viewer.route_viewer.route_viewer import RouteViewer

BRAKE_LINE_DATA = []
TROTTLE_LINE_DATA = []
STEERING_LINE_DATA = []


class RecordAnimator:
    def __init__(self, fn, map_fn):
        fig, ax = plt.subplots()
        self.figure = fig
        self.ax = ax
        self.related_time = 0
        self.text = ax.text(0.80, 0.95 * 0.05, '%.2f' % self.related_time, transform=ax.transAxes)

        X = range(10)
        Xs = [i * -1 for i in X]

        self.adv, = ax.plot(
            Xs, [0] * 10, 'b', lw=3, alpha=0.5)
        self.routing, = ax.plot([0], [0], lw=1, c='k')
        self.obstacles = []
        for i in range(20):
            line, = ax.plot([0], [0], lw=1, c='b')
            self.obstacles.append(line)

        self.lanes = []
        for i in range(20):
            line, = ax.plot([0], [0], lw=1, c='b')
            self.lanes.append(line)

        reader = AplRecordReader()
        self.generator = reader.read_messages(fn)

        self.map_fn = map_fn
        self.routing_response = None
        self.localization_pb = None
        self.perception_obstacle_pb = None
        self.routing_showed = False
        self.start_timestamp = None

        self.map_reader = MapReader(self.map_fn)
        self.map_reader.load_lane_id_to_coord()
        self.map_reader.load_xy_to_lane_id()

    def show(self):
        ani = animation.FuncAnimation(self.figure, self.update, interval=100)
        self.ax.set_ylim(-100, 120)
        self.ax.set_xlim(-1 * 10, 10)
        # self.ax.legend(loc="upper left")
        plt.show()

    def update(self, frame_number):
        while (True):
            msg = next(self.generator)
            if msg is None:
                break
            if msg.topic == "/apollo/perception/obstacles":
                self.perception_obstacle_pb = PerceptionObstacles()
                self.perception_obstacle_pb.ParseFromString(msg.message)
                if self.start_timestamp is None:
                    self.start_timestamp = self.perception_obstacle_pb.header.timestamp_sec
                current = self.perception_obstacle_pb.header.timestamp_sec
                diff = current - self.start_timestamp
                self.related_time = diff

                current_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(current))
                print(current_str, current, diff)
                self.plot()
                break

            elif msg.topic == "/apollo/localization/pose":
                self.localization_pb = localization_pb2.LocalizationEstimate()
                self.localization_pb.ParseFromString(msg.message)

            elif msg.topic == "/apollo/routing_response":
                self.routing_response = RoutingResponse()
                self.routing_response.ParseFromString(msg.message)
                self.routing_showed = False

    def plot(self):
        if self.localization_pb is not None:
            viewer = AgentViewer()
            x = self.localization_pb.pose.position.x
            y = self.localization_pb.pose.position.y
            px, py = viewer.get_agent_xy(self.localization_pb)
            self.adv.set_xdata(px)
            self.adv.set_ydata(py)
            self.text.set_text('%.2f' % self.related_time)
            self.ax.set_xlim(x - 50, x + 50)
            self.ax.set_ylim(y - 50, y + 50)

        if self.routing_response is not None and not self.routing_showed:
            route_viewer = RouteViewer(self.map_fn)
            x, y = route_viewer.get_routing_xy(self.routing_response)
            self.routing.set_xdata(x)
            self.routing.set_ydata(y)
            self.routing_showed = True

        for line in self.obstacles:
            line.set_xdata([0])
            line.set_ydata([0])

        for i in range(len(self.perception_obstacle_pb.perception_obstacle)):
            if i >= 20:
                break
            obs = self.perception_obstacle_pb.perception_obstacle[i]
            x, y = ObstacleViewer().get_obstacle_xy(obs)
            line = self.obstacles[i]
            line.set_xdata(x)
            line.set_ydata(y)

        #
        for line in self.lanes:
            line.set_xdata([0])
            line.set_ydata([0])

        if self.localization_pb is not None:
            x = self.localization_pb.pose.position.x
            y = self.localization_pb.pose.position.y
            lane_ids = self.map_reader.get_lane_ids(x, y)
            for i in range(len(lane_ids)):
                if i >= 20:
                    break
                lane_id = lane_ids[i]
                coords = self.map_reader.get_laneid_coord(lane_id)
                line = self.lanes[i]
                x = []
                y = []
                for coord in coords:
                    x.append(coord[0])
                    y.append(coord[1])
                line.set_xdata(x)
                line.set_ydata(y)
